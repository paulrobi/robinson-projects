"""
SAM CLI version
"""

__version__ = "1.43.0"
