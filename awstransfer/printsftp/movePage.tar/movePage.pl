#!/usr/bin/perl	

use DJ::Pagename;
use Getopt::Std;
use strict;
#use Mail::Sendmail;
use Sys::Hostname;
use File::Copy qw (cp mv);

use vars qw (%opts %config %currentFiles);
use vars qw ($configFile);
use vars qw ($file $logFolder $logFile $inFolder $destFolder $doneFolder $errorFolder);
use vars qw ($day $month $year $allowedPub $configFile);

getopts('c:',\%opts);
$configFile = $opts{'c'};

if ($configFile eq "") {
	$configFile = "/usr/local/bin/movePage.config";
}

getConfig ();

$inFolder = $config{FOLDER}{in_folder};
$destFolder = $config{FOLDER}{dest_folder};
$errorFolder = $config{FOLDER}{error_folder};
$doneFolder = $config{FOLDER}{done_folder};
$allowedPub = $config{ALLOWED_PUB}{pub};

while (1) {

	($day, $month, $year) = (localtime)[3,4,5];
	$logFolder = $config{FOLDER}{log_folder};
	$logFile = sprintf("Pagename-%02d-%02d-%04d.log", $month+1, $day, $year+1900);
	open (LOG, ">>$logFolder/$logFile");

	if (opendir (DIR, $inFolder)) {
		my @files = ();
		@files = grep !/^\./, readdir DIR;
		closedir DIR;

		# get information about the files in input
		foreach $file ( @files ) {
			if ( $currentFiles{$file}{status} ne "STABLE" ) {
				getFileDetails ($inFolder, $file, \%currentFiles);
			}           
		}       
	}
	else {
		logMsg ("");
		logMsg ("Failed to open in folder $inFolder");
		sendEMail ("Failed to open in folder $inFolder.");
#		exit;
	}

	foreach $file (keys %currentFiles) {
		checkFile ($inFolder, $file, \%currentFiles);

		if ($currentFiles{$file}{status} eq "STABLE") {
			processFile ($inFolder, $doneFolder, $file);
			delete $currentFiles{$file};
		}
		elsif ($currentFiles{$file}{status} eq "EXPIRED") {
			logMsg ("");
			logMsg ("$inFolder/$file is not stable after $config{timeout} seconds.  File will be moved to the $errorFolder");
			sendEMail ("$inFolder/$file is not stable after $config{timeout} seconds.  File will be moved to the $errorFolder");
			mv ("$inFolder/$file", $errorFolder);
			delete $currentFiles{$file};
		}
	}


	close LOG;

	sleep ($config{TIMER}{poll});
}


sub processFile
{
	my ($inFolder, $doneFolder, $file) = @_;

	my ($page, $pub, $allSite, $contractSite, $site, $siteFolder, $allEdition, $edition, $msg, $errMsg);

	my $zoption = ($file =~ /^\w{3,4}\.\w{2}\./) ? "CLASSF" : "";

	my ($pageName, $ext) = $file =~ /^(.*)\.(pdf|[a-zA-Z]\.[0-9]\.info)$/;

	logMsg ("");
	logMsg ("Processing $inFolder/$file.  Page name = $pageName, zoption = $zoption");

	if ($pageName eq "") {
		logMsg ("Failed to extract page name.");
		$errMsg = "Failed to extract page name from $inFolder/$file.  File will be moved to $errorFolder\n";
	}
	else {
		$page = DJ::Pagename->new (pagename => $pageName, z_options => $zoption);
		$pub = $page->get_pubname();
		logMsg ("Pub = $pub");

		unless ($allowedPub =~ /$pub/) {
			logMsg ("$pub pages will not be processed");
		}
		else {
			$allSite = $page->get_sites();
			logMsg ("Site list = $allSite");

			if ($allSite =~ /^\s*$/) {
				logMsg ("Failed to determine sites");
				$errMsg .= "Failed to determine sites for $inFolder/$file.  File will be moved to $errorFolder\n\n";
			}
			else {
				foreach $contractSite (split (/\s/, $config{CONTRACT_SITE_EXCLUSION}{contract_site})) {
					if ($allSite =~ /$contractSite/) {
						$allSite =~ s/$contractSite\s?//;

						logMsg ("Contract site $contractSite will be excluded.");

						# Sending WSJ and BARRONS Contract Site pages to appropriate CS backup folders
						# the CONTRACT_SITE_EXCLUSION contains list of contract sites for which we are not moving the page.
						# these pages are to be sent by QMS.
						# As a backup option, we need to backup these pages for CS, in case QMS fails to do so.
						if($pub eq "WSJ"){
							logMsg ("$pub page for Contract site $contractSite will be sent to the backup folder.");
							$errMsg .= sendPageToContractSite ($inFolder, $page, $file, $config{WSJ_CONTRACT_SITE_BACKUP_FOLDER}{$contractSite}, $pub);
						}
						elsif($pub eq "BARRONS"){
							logMsg ("$pub page for Contract site $contractSite will be sent to the backup folder.");
							$errMsg .= sendPageToContractSite ($inFolder, $page, $file, $config{BARRONS_CONTRACT_SITE_BACKUP_FOLDER}{$contractSite}, $pub);
						}
						elsif($pub eq "AWSJ"){
							logMsg ("$pub page for Contract site $contractSite will be sent to the backup folder.");
							$errMsg .= sendPageToContractSite ($inFolder, $page, $file, $config{AWSJ_CONTRACT_SITE_BACKUP_FOLDER}{$contractSite}, $pub);
						}
						elsif($pub eq "WSJE"){
							logMsg ("$pub page for Contract site $contractSite will be sent to the backup folder.");
							$errMsg .= sendPageToContractSite ($inFolder, $page, $file, $config{WSJE_CONTRACT_SITE_BACKUP_FOLDER}{$contractSite}, $pub);
						}
					}
				}

				foreach $site (split (/\s/, $allSite)) {
					if ($pub eq "WSJ" && $config{WSJ_CONTRACT_SITE_EXCEPTION}{contract_site} =~ /$site/) {
						logMsg ("WSJ contract site $site will be excluded");
						$errMsg .= sendPageToContractSite ($inFolder, $page, $file, $config{WSJ_CONTRACT_SITE_FOLDER}{$site}, $pub);
					}
					else {
						$siteFolder = $config{SITE_FOLDER}{$site};
						if ($siteFolder) {
							unless (cp ("$inFolder/$file", "$destFolder/$siteFolder/$file")) {
								logMsg ("Failed to copy file to $destFolder/$siteFolder");
								$errMsg .= "Failed to copy $inFolder/$file to $destFolder/$siteFolder.  File will be moved to $errorFolder\n\n";
							}
							else {
								logMsg ("Successfully copied $file to $destFolder/$siteFolder");
							}
						}
						else {
							logMsg ("No folder defined for site $site in the config file.  file couldn't be copied for $site");
							$errMsg .= "No folder defined for site $site in the config file.  $inFolder/$file couldn't be copied for this site.  File will be moved to $errorFolder\n\n";
						}

					}
				}
			}
		}
	}

	if ($errMsg) {
		sendEMail ($errMsg);
		logMsg ("Moving file to error folder $errorFolder");
		mv ("$inFolder/$file", $errorFolder);
	}
	else {
		logMsg ("Moving file to $doneFolder");
		mv ("$inFolder/$file", $doneFolder);
	}
}


sub getConfig
{

	my $prefix;

	die "Config file [$configFile] does not exist\n" if ( ! -e "$configFile" );

	open (CFG, "$configFile");

	while (<CFG>) {
		# Skip comments and blanks
		next if /^#/;
		next if /^\s*$/;

		# look for a [block] to set $prefix
		if (/^\[([^\]]+)\]$/) {
			$prefix = $1;
			next;
		}

		if (/^([^\s=]+)(?:(?:(?:\s*=\s*)|\s+)(.*))?/) {
			my ($variable, $value) = ($1, $2);

			# strip any quoting from the variable value
			if (defined $value) {
				$value =~ s/^(['"])(.*)\1$/$2/;
				$config{$prefix}{$variable} = $value;
			}
		}
	}
}


sub logMsg
{
	my $msg = shift;

	my ($hour, $min, $sec) = (localtime)[2,1,0];

	printf LOG ("%02d:%02d:%02d\t$msg\n", $hour, $min, $sec);
}


sub getFileDetails
{

	my ($inFolder, $file, $curFiles) = @_;

	# if file is deleted for some reason after we have seen it, remove it from list
	if ( ! -e "$inFolder/$file" ) {
		delete $curFiles->{$file}, if ( defined $curFiles->{$file} );
		return 0;
	}

	unless (defined $curFiles->{$file}{size}) {
		($curFiles->{$file}{size})  = (stat "$inFolder/$file" )[7];
	}

	unless (defined $curFiles->{$file}{size}) {
		($curFiles->{$file}{mtime})  = (stat "$inFolder/$file" )[9];
	}

	#--- get the current time, only first time around ---

	unless ( defined $curFiles->{$file}{start} ) {
		$curFiles->{$file}{start} = time();
	}
	return 1;
}


sub checkFile
{
	my ($inFolder, $file, $curFiles) = @_;

	my $stable = $config{TIMER}{stable};
	my $timeout = $config{TIMER}{timeout};

	my $size = (stat "$inFolder/$file")[7];
	my $mtime = (stat "$inFolder/$file")[9];

	# if first time mtime is same, then start the timer.  Else, check if file hasn't changed for more
	#than stable time

	if ($mtime == $curFiles->{$file}{mtime} && $size != 0) {
		unless (defined $curFiles->{$file}{startCheck} ) {
			$curFiles->{$file}{startCheck} = time();
		}
		else {
			my $delta = time() - int($curFiles->{$file}{startCheck});
			if ($delta > $stable) {
				$curFiles->{$file}{status} = "STABLE";
				return;
			}
		}
	}
	# if mtime is not same, then reset timer
	else {
		delete $curFiles->{$file}{startCheck};
		$curFiles->{$file}{mtime} = $mtime;
	}

	# if more than time out, then file has expired
	if ((time() - $curFiles->{$file}{start}) >= $timeout) {
		$curFiles->{$file}{status} = "EXPIRED";
	}
	else {
		$curFiles->{$file}{status} = "RETRY";
	}
}


sub sendEMail
{
	my $msg = shift;

	my $hostname = hostname();
#	my %mail = (
#		SMTP => "mailhost.mcn.dowjones.com",
#		From => "GAMS\@dowjones.com",
#		To => "$config{NOTIFICATION}{admin_email}",
#		Subject => "Error processing pages on sftp server $hostname",
#		Message => "$msg\n"
#	);

	my $subject = "Error processing pages on sftp server $hostname";

        my $x = "echo \"$msg\" | mail -s \"$subject\" $config{NOTIFICATION}{admin_email}";
	`$x`;
}


sub sendPageToContractSite
{
	my ($inFolder, $page, $file, $contractSiteFolder, $pub) = @_;

	my ($toFolder, $pageStar, $pageStarMap, $pageVersion, $oldVersion, $msg);
	my ($oldFileName, $newFileName, $extractPDF);

	logMsg ("Copying file to $pub contract site $contractSiteFolder");
	$pageStar = $page->get_star();
	$pageStarMap = $config{"${pub}_STAR_MAP"}{$pageStar};
	$pageVersion = $page->get_version();
	$oldVersion = $pageVersion - 1;

	logMsg ("Using $pageStarMap for $pub");
	$contractSiteFolder =~ s/\s//g;

	foreach $toFolder (split (/,/, $contractSiteFolder)) {

		$toFolder = "$toFolder/$pageStarMap";

		if (-d $toFolder) {
			if ($file =~ /^(P[\dA-Z]{3}\d{3}[\dA-Z]{3}-\d[\-A-Z][A-Z]\d{3}[0A-Z][0A-Z]-)(\d)(.*)\.(pdf|[FS]\.\d\.info)$/) {
				$oldFileName = "$1$oldVersion$3.pdf";
				$newFileName = "$1$2$3.pdf";
				$extractPDF = 1, if ($4 ne "pdf");
			}
			elsif ($file =~ /^([\dA-Z]{3,4}\.[\dA-Z]{2}\.\d[A-Z]\d{2}[0A-Z]\.[A-Z])(\d)(.*)\.(pdf|[FS]\.\d\.info)$/) {
				$oldFileName = "$1$oldVersion$3.pdf";
				$newFileName = "$1$2$3.pdf";
			}
			else {
				logMsg ("Failed to parse page name.  Older version of page will not be deleted if it exists and page will be saved as is");
				$msg .= "Failed to parse page name.  Older version of page will not be deleted if it exists in $toFolder.\n\n.$file will be saved to $toFolder as is\n\n";
				$newFileName = $file;
			}

			if ($pageVersion > 1 && $oldFileName ne "") {
				unlink ("$toFolder/$oldFileName");
				logMsg ("Deleting file $toFolder/$oldFileName as older version of page");
			}

			if ($extractPDF == 1) {
				my $pdfName = $config{MISC}{pdf_name_in_tar};
				`/bin/tar xf $inFolder/$file -C $toFolder $pdfName`;
				mv ("$toFolder/$pdfName", "$toFolder/$newFileName");
			}
			elsif ($pageStarMap eq "") {
				$msg .= "Star folder for $pub page $file is not defined. File will be moved to $errorFolder\n\n";
				logMsg ("Star folder for $pub page $file is not defined. File will be moved to $errorFolder");
			}
			else {
				cp ("$inFolder/$file", "$toFolder/$newFileName");
			}

			unless (-e "$toFolder/$newFileName") {
				logMsg ("Failed to copy $inFolder/$file to $toFolder/$newFileName");
				$msg .= "Failed to copy $inFolder/$file to $toFolder/$newFileName.  File will be moved to $errorFolder\n\n";
			}
			else {
				chmod ( 0644, "$toFolder/$newFileName" );
				logMsg ("Successfully copied $file to $toFolder/$newFileName");
			}
		}
		else {
			logMsg ("Folder $toFolder doesn't exist.  $pub page cannot be saved.");
			$msg .= "Folder $toFolder doesn't exist.  $pub page cannot be saved for contract print site";
		}
	}

	return $msg;
}


