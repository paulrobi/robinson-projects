package DJ::Pagename;

#-- Start RCS versioning --#
$rcs  =<<'RCS';
# $Id: Pagename.pm,v 1.24 2004/11/05 19:35:04 root Exp root $
# $Revision: 1.24 $
# $Author: root $
# $Date: 2004/11/05 19:35:04 $
#
# History:
# $Log: Pagename.pm,v $
# Revision 1.24  2004/11/05 19:35:04  root
# *** empty log message ***
#
# Revision 1.23  2002/06/25 23:23:21  root
# Corrected gen_unique_name to properly handle ADI and A/B Split pages.
#
# Revision 1.22  2002/06/24 20:33:43  root
# Corrected problem with intl page names having day and month backwards.
#
# Revision 1.21  2002/06/21 16:44:12  root
# Added set_distribution and modified the gen_uniquename to regenerate the supername
# instead of just returning it.
#
# Revision 1.20  2002/01/29 19:35:16  root
# Fixed problem with gen_pagename_18 using multi-character source sites.
# Added gen_intl_name.
# Make slightly better guesses at pubcodes.
#
# Revision 1.19  2001/12/10 21:45:16  root
# More changes to parsing section.
# Removed reliance on AppConfig - added function to get config parameters.
# Modified to allow groupcodes and bitfields to be based upon publication.
#
# Revision 1.18  2001/12/10 21:41:14  root
# Corrected parsing of pagename.
# Better handling for international, moved codes to config file.
# Better error handling for getting editions from pageid.
#
# Revision 1.17  2001/10/05 21:14:01  root
# Fixed gen_pagename_18 so it uses the correct source site.
#
# Revision 1.16  2001/09/19 15:12:41  root
# Added code to support city editions for AWSJ and replates.
#
# Revision 1.15  2001/09/19 14:58:29  root
# Added hack to allow groupcode for AWSJ pages to be the edition code as well.
#
# Revision 1.14  2001/08/22 21:57:06  root
# Added code to handle naming conventions for AWSJ pages.
#
# Revision 1.13  2001/08/11 17:55:43  root
# Removed a STDERR debugging message.
#
# Revision 1.12  2001/08/11 17:53:45  root
# Support classified pages with names like MART.MW.1A010.A1-SH.cpsiflatbed2
#
# Revision 1.11  2001/07/31 23:27:14  root
# updated set_groupcode to handle Sunday Journal:
# set sites to a space since they are not printed to a site.
# added get_unique_name to convert route codes to ext. route codes
# and fax codes to super-extended faxcodes.
#
# Revision 1.10  2001/06/22 13:45:12  root
# Modified pattern match for Classified pages named with Route Codes.
# The original pattern was a bit restrictive and when different RIPs were used
# in Orlando, the match failed. Now, I allow any non-space characters to trail the route code; but first I
# check for an extended route code.
#
# Revision 1.9  2001/06/13 22:37:49  root
# Fixed parser for all pagenames to accept groupcodes containing numbers as well as letters.
#
# Revision 1.8  2001/06/01 18:52:30  root
# Changed get_paged_editions function to return embedded groupcode for SunJ pages.
#
# Revision 1.7  2001/05/28 13:25:34  root
# Added code to parse WSJE name.
#
# Revision 1.6  2001/04/09 17:11:49  root
# Changed path to configuration file from /usr/midsys/site/ to
# /usr/local/lib/perl5/site_perl/5.005/DJ
#
# Revision 1.5  2001/04/09 17:07:17  root
# Modified extract_pid_editions to strip off julian dates if the
# pagename type is extended routecode or super extended fax code.
#
# Revision 1.4  2001/04/09 17:00:55  root
# Added pageid config variables to configuration file
# Added gen_supername_18 function
# Started adding extract_pid_editions function
# Added some more examples on how to use the module in the documentation.
#
# Revision 1.3  2000/10/04 12:52:58  root
# Added to_string method.
#
RCS
#-- End of RCS versioning --#

###############################################################
# Modification log:Modification to handle Barron's publication
#                  not being assosciated with Contract Printing
#                  sites.
#
# Incident Reference         Date            Author
#
# Mercury ID:31620           11 Mar 2007     Infosys
###############################################################
# Modification log:Fixed Decimal to binary convertion for the
#                  decimal values greater than 2 power 32.
#
# Incident Reference         Date            Author
#
# Mercury ID:             24 May 2010         Infosys
###############################################################


#-- Let RCS handle taking care of versioning the module
#$rcs =~ /Revision: (.+)\s*\$/g;
#$VERSION = $1;

use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK);
use Carp;
use Data::Dumper;
use Time::Local;
use Net::Ping;
#use LWP::Simple;
#use LWP::UserAgent;

my $ds = "DJ::Pagename";

require Exporter;
#use AutoLoader 'AUTOLOAD';

@ISA = qw(Exporter);
@EXPORT = qw( );

our $VERSION = '1.24';

sub new {
        my ($class, %args) = @_;

        my $self = {
                _pagename       => undef,
                _pubname        => undef,
                _pubcode        => undef,
                _pubkey         => undef,
                _pubdate        => undef,
                _julpubdate     => undef,
                _dateindex      => undef,
                _section        => undef,
                _pagenum        => undef,
                _star           => undef,
                _version        => undef,
                _editions       => undef,
                _herm_edition   => undef,
                _sites          => undef,
                _site_names     => undef,
                _bitfield       => undef,
                _groupcode      => undef,
                _adibreakout    => undef,
                _absplit        => undef,
                _pagetype       => undef,
                _creator        => undef,
                _uniqueseqno    => undef,
                _formatnum      => undef,
                _pagenametype   => undef,
                _source_site_code       => undef,
                _cfg            => undef,
                _delimiter      => "<::>",
        };

        bless $self, $class;

        $self->{_cfg} = $self->read_config("Pagename.conf");

        if ($args{pagename}) {
                $self->parse(%args);
        }

        return $self;
}

sub read_config {

        my $self = shift;
        my $file = shift;
        my $prefix = "global";
        my %cfg;
        if ($file) {
                my $filename = $file;
                unless(-f $file) {
                        #-- check each perl include path + "DJ" for the config file, then /pagedisk/filters
                        my @paths = map { "${_}/DJ" } @INC;
                        foreach my $path ( @paths, "/pagedisk/filters" ) {
                                if(-f "$path/$filename") {
                                        $file = "$path/$filename";
                                        last;
                                }
                        }
                }
                local *FH;
                open (FH, $file) or return undef;
                while (<FH>) {
                        chomp;

                        # ignore blank lines and comments
                        next if /^\s*$/ || /^#/;

                        # strip leading and trailing whitespace
                        s/^\s+//;
                        s/\s+$//;

                        # look for a [block] to set $prefix
                        if (/^\[([^\]]+)\]$/) {
                                $prefix = $1;
                                next;
                        }

                        if (/^([^\s=]+)(?:(?:(?:\s*=\s*)|\s+)(.*))?/) {
                                my ($variable, $value) = ($1, $2);

                                # strip any quoting from the variable value
                                if (defined $value) {
                                        $value =~ s/^(['"])(.*)\1$/$2/;

                                        $cfg{$prefix}{$variable} = $value;
                                }
                        }
                }
        }

        return \%cfg;

}

sub parse {
        my $self = shift;
        my %args = @_;
        my $pagename = $args{pagename};
        my $Z = $args{z_options} || "";

        #$self->{_cfg} = $self->read_config("Pagename.conf");

        $self->set_pagename($pagename);
        if ($pagename =~ /([A-Z])(2)([A-Z])([A-Z])(\d{3})([A-Z0-9]{3})-(\d)([\-A-Z])([A-Z])(\d{3})([0A-Z])([0A-Z])-(\d)([A-Z0-9\-])([A-Z0-9\-]{7})([A-Z0-9]{2})/) {
                #-- Match on Pagename Version 2
                #-- 2.0 Example: P2JW2703E4-0-A00100-1FFFFFFFFFF
                #-- 2.1 Example: P2JW2703E4-0-A00100-1--------XE
                $self->set_pubcode($3);
                $self->set_pagetype($1);
                $self->set_formatnum($2);
                $self->set_creator($4);
                $self->set_julpubdate($5);
                $self->set_uniqueseqno($6);
                $self->set_star($7);
                $self->set_section($8.$9);
                $self->set_pagenum($10);
                $self->set_adibreakout($11);
                $self->set_absplit($12);
                $self->set_version($13);
                if ($14 eq "-") {
                        $self->set_groupcode($16);
                        $self->set_pagenametype("2.1_PAGENAME");
                        $self->{_pagenameversion} = 2;
                } else {
                        $self->set_bitfield($14.$15.$16);
                        $self->set_pagenametype("2.0_PAGENAME");
                        $self->{_pagenameversion} = 2;
                }

        } elsif ($pagename =~ /([A-Z])(\d)([A-Z])([A-Z])(\d{3})([A-Z0-9]{3})-(\d)([\-A-Z])([A-Z])(\d{3})([0A-Z])([0A-Z])-(\d)([A-Z0-9\-])([A-Z0-9\-]{2})([A-Z0-9]{2})/) {
                #-- Match on Pagename Version 1.7/1.8
                #-- 1.7 Example: P1JW2703E4-0-A00100-11FFFF
                #-- 1.8 Example: P1JW2703E4-0-A00100-1---XE
                $self->set_pubcode($3);
                $self->set_pagetype($1);
                $self->set_formatnum($2);
                $self->set_creator($4);
                $self->set_julpubdate($5);
                $self->set_uniqueseqno($6);
                $self->set_star($7);
                $self->set_section($8.$9);
                $self->set_pagenum($10);
                $self->set_adibreakout($11);
                $self->set_absplit($12);
                $self->set_version($13);
                if ($14 eq "-") {
                        $self->set_groupcode($16);
                        $self->set_pagenametype("1.7_PAGENAME");
                } else {
                        $self->set_bitfield($14.$15.$16);
                        $self->set_pagenametype("1.8_PAGENAME");
                }
        } elsif ($pagename =~ /(\d)([A-Z])(\d{2})([0A-Z])([A-Z0-9]{2})([A-Z])(\d)([A-Z]{2})(\d{3})?([A-Z])?/) {
                #-- Match on Super Extended Fax Code or Extended Fax Code
                #-- Super Extended Faxcode Examle: 1C090XEA1XE139J
                #-- Extended Fax Code Examle: 1C090XEA1XE
                if ($9 && $10) {
                        $self->set_pubcode($10);
                        $self->set_julpubdate($9);
                        $self->set_pagenametype("SUPER_EXTENDED_FAXCODE");
                } else {
                        $self->set_pagenametype("EXTENDED_FAXCODE");
                        #$self->set_pubcode("J");
                        $self->set_pubcode($self->guess_pubcode());
                        $self->set_julpubdate($self->get_next_pub_date_j());
                }
                $self->set_star($self->fix_star($1));
                $self->set_section($2);
                $self->set_pagenum($3);
                $self->set_overloaded_absplit($4);
                $self->set_groupcode($5);
                $self->set_version($7);

        } elsif ($pagename =~ /(\d)([A-Z])(\d{2})([0A-Z])([A-Z0-9]{2})([A-Z])(\d)(\d{3})?([A-Z])?/) {
                #-- Match on Super Fax Code or Fax Code
                #-- Super Fax code example: 1C090XEA1189J
                #-- Fax code example: 1C090XEA1
                if ($8 && $9) {
                        #-- we have a Super Fax Code
                        $self->set_pagenametype("SUPER_FAXCODE");
                        $self->set_pubcode($9);
                        $self->set_julpubdate($8);
                } else {
                        #-- we have a Fax Code
                        #-- This is a BIG GUESS! We don't really
                        #-- have any idea what the pub is or what the pub
                        #-- date is from this type of pagename
                        $self->set_pagenametype("FAXCODE");
                        #$self->set_pubcode("J");
                        $self->set_pubcode($self->guess_pubcode());
                        $self->set_julpubdate($self->get_next_pub_date_j());

                }

                $self->set_star($self->fix_star($1));
                $self->set_section($2);
                $self->set_pagenum($3);
                $self->set_overloaded_absplit($4);
                $self->set_groupcode($5);
                $self->set_version($7);

        } elsif ($Z =~ /CLASSF/ &&
$pagename =~ /^([A-Z]+)\.([A-Z0-9]{2})\.(\d)([A-Z])(\d{2})([0A-Z])\.([A-Z])(\d)(-[A-Z0-9]+|\..+|-[A-Z0-9]+\..+|[0-9]{3}[A-Z])?$/) {
                #-- in this match, the portion after .A1 is optional, hence the ? signifying 0|1

                #-- Match on Route Code generated by Classified and identified as classified by
                #-- the CLASSF Z-option
                #-- Route code examples:        MART.MW.1A010.A1
                #--                                                             MART.MW.1A010.A1-SH
                #--                                                             MART.MW.1A010.A1-SH.189J
                #--                                                             MART.MW.1A010.A1-SH.cpsiflatbed2
                #--                                                             MART.MW.1A010.A1.anonymous.4515
                #--                                                             MART.MW.1A010.A1-SH.anonymous.4515
                my $creator = $1;
                my $groupcode = $2;
                my $star = $3;
                my $section = $4;
                my $pagenum = $5;
                my $absplit = $6;
                my $version = $8;
                my $date = $9;
                if ($date =~ /([0-9]{3})([A-Z])/) {
                        $self->set_julpubdate($1);
                        $self->set_pubcode($2);
                } else {
                        $self->set_pubcode($self->guess_pubcode());
                        $self->set_julpubdate($self->get_next_pub_date_j());
                        #$self->set_pubcode("J");
                }
                $self->set_creator($creator);
                $self->set_groupcode($groupcode);
                $self->set_star($self->fix_star($star));
                $self->set_section($section);
                $self->set_pagenum($pagenum);
                $self->set_overloaded_absplit($absplit);
                $self->set_version($version);
                $self->set_source_site_code("C");
                $self->set_pagenametype("CLASS_ROUTECODE");

        } elsif ($pagename =~ /^([A-Z]+)\.([A-Z0-9]{2})\.(\d)([A-Z])(\d{2})([0A-Z])\.([A-Z])(\d)\.(\d{3})([A-Z])$/) {

                #-- Match on Extended Route Code
                #-- Extended Route code example: EPM.XE.1A010.A1.189J
                $self->set_pubcode($10);
                $self->set_creator($1);
                $self->set_groupcode($2);
                $self->set_star($self->fix_star($3));
                $self->set_section($4);
                $self->set_pagenum($5);
                $self->set_overloaded_absplit($6);
                $self->set_version($8);
                $self->set_julpubdate($9);
                $self->set_pagenametype("EXTENDED_ROUTECODE");

        } elsif ($pagename =~ /^([A-Z]+)\.([A-Z0-9]{2})\.(\d)([A-Z])(\d{2})([0A-Z])\.([A-Z])(\d)(-[A-Z0-9]+|\..+|-[A-Z0-9]+\..+)$/) {
                #-- in this match, the portion after .A1 is required for CLASS, hence no ?

                #-- Match on Route Code generated by Classified and identified as classified by
                #-- the CLASSF Z-option
                #-- Route code examples:        MART.MW.1A010.A1-SH
                #--                                                             MART.MW.1A010.A1-SH.cpsiflatbed2
                #--                                                             MART.MW.1A010.A1.anonymous.4515
                #--                                                             MART.MW.1A010.A1.cpsiflatbed2
                #--                                                             MART.MW.1A010.A1-SH.anonymous.4515
                #$self->set_pubcode("J");
                $self->set_pubcode($self->guess_pubcode());
                $self->set_julpubdate($self->get_next_pub_date_j());
                $self->set_creator($1);
                $self->set_groupcode($2);
                $self->set_star($self->fix_star($3));
                $self->set_section($4);
                $self->set_pagenum($5);
                $self->set_overloaded_absplit($6);
                $self->set_version($8);
                $self->set_source_site_code("C");
                $self->set_pagenametype("CLASS_ROUTECODE");

        } elsif (0 && $pagename =~ /([A-Z]+)\.([A-Z0-9]{2})\.(\d)([A-Z])(\d{2})([0A-Z])\.([A-Z])(\d)(\.\S+|-[A-Z0-9]+)/) {

                #-- Match on Route Code generated by Classified
                #-- Route code examples: EPM.XE.1A010.A1.anonymous.4515
                #--     EPM.XE.1A010.A1.cpsiflatbed2
                #--     EPM.XE.1A010.A1.orrip2fb1
                #$self->set_pubcode("J");
                $self->set_pubcode($self->guess_pubcode());
                $self->set_julpubdate($self->get_next_pub_date_j());
                $self->set_creator($1);
                $self->set_groupcode($2);
                $self->set_star($self->fix_star($3));
                $self->set_section($4);
                $self->set_pagenum($5);
                $self->set_overloaded_absplit($6);
                $self->set_version($8);
                $self->set_source_site_code("C");
                $self->set_pagenametype("CLASS_ROUTECODE");

        } elsif (0 && $pagename =~ /([A-Z]+)\.([A-Z0-9]{2})\.(\d)([A-Z])(\d{2})([0A-Z])\.([A-Z])(\d)-[A-Z0-9][A-Z0-9]/) {
                #-- Match on Route Code generated by Classified with extended site info
                #-- Fax code examples: MART.MW.1A010.A1-SH.cpsiflatbed2
                #--$self->set_pubcode("J");
                $self->set_pubcode($self->guess_pubcode());
                $self->set_julpubdate($self->get_next_pub_date_j());
                $self->set_creator($1);
                $self->set_groupcode($2);
                $self->set_star($self->fix_star($3));
                $self->set_section($4);
                $self->set_pagenum($5);
                $self->set_overloaded_absplit($6);
                $self->set_version($8);
                $self->set_source_site_code("C");
                $self->set_pagenametype("CLASS_ROUTECODE");

        } elsif ($pagename =~ /([A-Z]+)\.([A-Z0-9]{2})\.(\d)([A-Z])(\d{2})([0A-Z])\.([A-Z])(\d)/) {

                #-- Match on simplest type of Route Code
                #-- Extended Fax code example: EPM.XE.1A010.A1
                #-- the first two calls are a BIG GUESS! We don't really
                #-- have any idea what the pub is or what the pub
                #-- date is from this pagename
                #-- TODO:
                $self->set_pubcode($self->guess_pubcode());
                $self->set_julpubdate($self->get_next_pub_date_j());
                #$self->set_pubcode("J");
                $self->set_creator($1);
                $self->set_groupcode($2);
                $self->set_star($self->fix_star($3));
                $self->set_section($4);
                $self->set_pagenum($5);
                $self->set_overloaded_absplit($6);
                $self->set_version($8);
                $self->set_pagenametype("ROUTECODE");

        } elsif ($pagename =~ /WSJE_(\d{6})_P(\d\d)\.pdf/) {
                #-- Match name for WSJE_PDF.
                #-- WSJE_110401_P01.pdf
                $self->set_pubcode("G");
                $self->set_julpubdate($self->ddmmyy_to_jul($1));
                $self->set_creator("E");
                $self->set_groupcode("LM");
                $self->set_star("0");
                $self->set_section("A");
                $self->set_pagenum($2);
                $self->set_overloaded_absplit("0");
                $self->set_version("1");
                $self->set_pagenametype("WSJE_PDF");
                $self->set_source_site_code("E");
        } elsif ($pagename =~ /([01]\d[0-3]\d\d\d)_(\w)(\d\d)_(.+?)(_r\d)?\.pdf/) {
                #-- Match name for AWSJ_PDF.
                #-- 060701_p01_politics.pdf
                my $pdate = $1;
                my $section = $2;
                my $pagenum = $3;
                my $replate = $5;
                # h=HongKong=HK, j=Japan=JP, i=Indoneisa=JA, b=Bangkok=TH, k=S.Korea=KO,
                # m=Malaysia=MA, p=Philippines=PH, s=Singapore=SI and t=Taiwan=TA
                #my %intl_sites = (
                #       h => 'HK', #-- Hong Kong
                #       i => 'JA', #-- Jakarta, Indonesia
                #       j => 'JP', #-- Japan
                #       b => 'TH', #-- Bangkok, Thailand
                #       k => 'KO', #-- South Korea
                #       m => 'MA', #-- Malaysia
                #       p => 'PH', #-- Phillipines
                #       s => 'SI', #-- Singapore
                ##      t => 'TA', #-- Taiwan
                #);
                #-- AN = Asia National
                my $code = $4;
                if ($code =~ /_(\w)$/) {
                        $code = $1;
                }
                $self->set_groupcode($self->cfg->{intlcode}->{$code} || "AN");
                #$self->set_groupcode($intl_sites{$code} || "AN");
                $self->set_pubcode("H");
                $self->set_julpubdate($self->mmddyy_to_jul($pdate));
                $self->set_creator("A");
                $self->set_star("0");
                $self->set_section(uc("$section"));
                $self->set_pagenum($pagenum);
                $self->set_overloaded_absplit("0");
                if ($replate =~ /r(\d)/i) {
                        $self->set_version($1 + 1);
                } else {
                        $self->set_version("1");
                }
                $self->set_pagenametype("AWSJ_PDF");
                $self->set_source_site_code("A");

        } elsif ($pagename =~ /(\d{6})-(\w+)-+([A-z0-9]+)-(\d\d\d)(\d)-(\S\S)-(\S\S)-(\S)(\d)-(\S{5})$/) {

                $self->set_pagenametype("AWSJ_PDF");
                $self->set_source_site_code("A");
                my $pdate = $1;
                my $star;
                $self->set_julpubdate($self->ddmmyy_to_jul($pdate));
                $self->set_pubcode(uc($2));
                $self->set_section(uc($3));
                $self->set_pagenum($4);
                $self->set_adibreakout($5);
                $self->set_absplit("0");
                my $edition = $6;
                if ($edition eq 'RE') {
                        $star = 0;
                } else {
                        $star = 2;
                }
                $self->set_star($star);
                #-- next two are ignored for now
                my $merge = $7;
                my $sing_doub = $8;
                $self->set_version($9);
                my $distribution = $10;
                #-- remove leading dashes
                $distribution =~ s/^-*//;
                my $key = $self->pubkey();
                if(defined $self->cfg->{"${key}_code"}->{$distribution}) {
                        $self->set_groupcode($distribution);
                } else {
                        my $sitelist;
                        if ($distribution =~ /^(\S+)Y$/) {
                                #-- sites to include
                                my @oldsites = split / */,$1;
                                my $sum = 0;
                                my @newsites;
                                foreach my $oldsite (@oldsites) {
                                        push @newsites, $self->cfg->{intlcode}->{lc($oldsite)};
                                }
                                $sitelist = join " ", sort @newsites;
                        } elsif ($distribution =~ /^(\S+)X$/) {
                                #-- sites to exclude
                                        my @oldsites = split / */,$1;
                                #-- 1. build a list of all valid sites
                                my %oldsites = map { $_ => 1 } keys %{$self->cfg->{intlcode}};
                                #-- 2. Remove each site found in the name
                                foreach my $oldsite (@oldsites) {
                                        delete $oldsites{lc($oldsite)};
                                }
                                #-- 3. Build sitelist string of remaining
                                my @newsites;
                                foreach my $oldsite ( keys %oldsites ) {
                                        push @newsites, $self->cfg->{intlcode}->{$oldsite};
                                }
                                $sitelist = join " ", @newsites;
                        }
                        $self->set_distribution($sitelist);
                }


        #} elsif ($pagename =~ /^([A-Z])?([0-9]{3})_(v([0A-Z])_)?(r(\d)_)?([A-Z]+)_(z(([A-Z]{2})$10+)_)?(\d{4})(\d{2})(\d{2}).*$/ ) {
        } elsif ($pagename =~ /^([A-Z])?([0-9]{3})([A-Z])?_(v([0A-Z])_)?(r(\d)_)?([A-Z]+)_(z(([A-Z]{2})$10+)_)?(\d{4})(\d{2})(\d{2}).*$/ ) {
                #-- Match name for  Glossy Pursuits.
                #-- [2010/08/30 The new format will have an optional charafter the page number.
                #-- SectionPageNumber<NewOptionalChar>_vVersion_rRevision_MagName_zZoneList_EditionDate_BWOnlyPMSorLowRes

                #my $pname = "$1$2_$3$7_$8$11$12$13";
                #my $pdate = "$12/$13/$11";
                #my $zoneList = $9;
                #my $version = $6 + 1;
                my $pname = "$1$2$3_$4$8_$9$12$13$14";
                my $pdate = "$13/$14/$12";
                my $zoneList = $10;
                my $version = $7 + 1;
                my $section = ( $1 ) ? $1 : "A";
                my $cur = 0;
                my $editions = "";
                while( $cur < length($zoneList)){
                        $editions .= substr($zoneList, $cur , 2)." ";
                        $cur += 2;
                }
                $self->set_adibreakout($3);
                $self->set_pagename($pname);
                $self->set_editions($editions);
                $self->set_pubdate($pdate);
                $self->set_section($section);
                $self->set_pagenum($2);
                #$self->set_absplit($4);
                $self->set_absplit($5);
                $self->set_version($version);
                #$self->set_pubname($7);
                $self->set_pubname($8);
                $self->set_pagenametype("GLOSSY");

        } elsif ($pagename =~ /^(CV\d|\d\d\d)R(\d\d)(A|B)V(\d\d)SMY(\d{6})(.*)$/) {
                #-- SmartMoney Magazine pagename
                #-- example: 012R01BV01SMY090110_0CC20
                my $pagenum = $1;
                my $runnumber = $2;
                my $absplit = $3;
                my $version = $4;
                my $pubdate = $5;
                my $quadjobcode = $6;

                # SmartMoney doesn't have a notion of "stars" but in order
                # for the E-Tearsheet system to sort pages by version (and star)
                # properly, we must set the star.
                $self->set_star(0);

                # page number can be the cover, or an inside page
                my $section = "INSIDE";
                if($pagenum =~ /^CV(\d)/) {
                        $section = "COVER";
                        $pagenum = $1;
                }
                $self->set_section($section);
                $self->set_pagenum($pagenum);
                $self->set_absplit($absplit);

                if($pubdate =~ /^(\d\d)(\d\d)(\d\d)/) {
                        # todo: fix this in the year 2100 :)
                        my ($month, $day, $year) = ($1, $2, $3 + 2000);
                        $self->set_pubdate( sprintf("%02d/%02d/%04d", $month, $day, $year) );
                }

                $self->set_pubname("SMARTMONEY");
                $self->set_pubcode("M");
                $self->set_version($version);
                $self->set_pagenametype("SMARTMONEY");

        } else {
                $self->set_pagenametype("UNKNOWN");
        }


}

#------------------------------------
#-- Public get methods
#------------------------------------
sub get_pagename {
        $_[0]->{_pagename};
}
sub get_pubname {
        $_[0]->{_pubname};
}
sub get_pubcode {
        $_[0]->{_pubcode};
}
sub get_pubdate {
        $_[0]->{_pubdate};
}
sub get_julpubdate {
        $_[0]->{_julpubdate};
}
sub get_dateindex {
        $_[0]->{_dateindex};
}
sub get_section {
        $_[0]->{_section};
}
sub get_pagenum {
        $_[0]->{_pagenum};
}
sub get_star {
        $_[0]->{_star};
}
sub get_version {
        $_[0]->{_version};
}
sub get_editions {
        $_[0]->{_editions};
}
sub get_herm_edition {
        $_[0]->{_herm_edition};
}
sub get_sites {
        $_[0]->{_sites};
}
sub get_site_names {
        map {$_[0]->cfg->{"$_[0]->{_pubkey}"."_site"}{$_}} split / /, $_[0]->{_sites};
}
sub get_bitfield {
        $_[0]->{_bitfield};
}
sub get_groupcode {
        $_[0]->{_groupcode};
}
sub get_adibreakout {
        $_[0]->{_adibreakout};
}
sub get_absplit {
        $_[0]->{_absplit};
}
sub get_pagetype {
        $_[0]->{_pagetype};
}
sub get_creator {
        $_[0]->{_creator};
}
sub get_uniqueseqno {
        $_[0]->{_uniqueseqno};
}
sub get_formatnum {
        $_[0]->{_formatnum};
}
sub get_pagenametype {
        $_[0]->{_pagenametype};
}
sub get_source_site_code {
        $_[0]->{_source_site_code};
}
sub gen_supername_18 {
        #-- generate a 26-character pagename
        #-- EG:  P1JW023000-0-A00100-1---XA
        #--
        #-- Note: this function was written with the expectation
        #-- that the initial parsing of the pagename will be done
        #-- from a special routecode: CLASS_ROUTECODE.
        #-- This special routecode is one generated
        #-- by the classified systems in NCC and ORL.
        #-- Examples look like this:
        #-- MART.XE.1A010.A1.cpsiflatbed or
        #-- MART.XE.1A010.A1.anonym.3442
        #-- As a result, we make certain assumptions about the
        #-- source site code - I set it here to 'C' just to mean
        #-- classified sites (which are NCC and ORL).
        #-- We also set the unique sequence number to 000
        #-- and we assume the groupcode has already been
        #-- set in this object during the parsing.

        # gen_supername_18 to accept an additional parameter, uniqueseqno.
        # If this parameter is passed, then the function should use it instead of 000 as the PID seq no.
        my ($self, $uniqueseqno) = @_;
        if ($uniqueseqno eq "") {
                $uniqueseqno = "000-";
        } else {
                $uniqueseqno .= "-";
        }


        #-- create the julian pubdate as 3 characters
        my $julpubdate = $_[0]->{_julpubdate};
        while (length($julpubdate) < 3) {
                $julpubdate = "0$julpubdate";
        }

        #-- create the page section as 2 characters
        my $section = $_[0]->{_section};
        while (length($section) < 2) {
                $section = "-$section";
        }

        #-- create the page number as 3 characters
        my $pagenum = $_[0]->{_pagenum};
        while (length($pagenum) < 3) {
                $pagenum = "0$pagenum";
        }

        my $creator;
        if (length $_[0]->{_source_site_code} < 1) {
                if (length $_[0]->{_creator} < 1) {
                        $creator = "W";
                } else {
                        #-- $creator = $_[0]->{_creator};
                        $creator = substr($_[0]->{_creator},0,1);
                }
        } else {
                #-- $creator = $_[0]->{_source_site_code};
                $creator = substr($_[0]->{_source_site_code},0,1);
        }

        my $destination;
        my $prefix = "P1";
        if(defined $_[0]->{_pagenameversion} && $_[0]->{_pagenameversion} == 2) {
                $prefix = "P2";
        }
        if (! $_[0]->{_groupcode} ) {
                $destination = $_[0]->get_bitfield();
        } else {
                $destination = "---" . $_[0]->{_groupcode};
                if(defined $_[0]->{_pagenameversion} && $_[0]->{_pagenameversion} == 2) {
                        $destination = "-----" . $destination;
                }
        }


        my $name =                      $prefix .
                                        $_[0]->{_pubcode} .
                                        $creator .
                                        $julpubdate .
                                        $uniqueseqno .
                                        $_[0]->{_star} .
                                        $section .
                                        $pagenum .
                                        $_[0]->{_adibreakout} .
                                        $_[0]->{_absplit} .
                                        "-" .
                                        $_[0]->{_version} .
                                        $destination;

        return $name;
}

sub gen_unique_name {

        my $self = shift;
        my $pagename = $self->get_pagename();
        my $ptype = $self->get_pagenametype();

        if ( $ptype eq "1.7_PAGENAME" ||
             $ptype eq "1.8_PAGENAME") {


                my $section = $self->get_section();
                $section = length $section eq 2 ? $section : "-$section";

                my $destination;
                if (length $self->get_bitfield() < 1 ) {
                        $destination = "---" . $self->get_groupcode();
                } else {
                        $destination = $self->get_bitfield();
                }

                my $temp_name = sprintf("%s%s%s%s%03d%s-%d%s%03d%s%s-%d%s",
                        $self->get_pagetype(),
                        $self->get_formatnum(),
                        $self->get_pubcode(),
                        $self->get_creator(),
                        $self->get_julpubdate(),
                        $self->get_uniqueseqno(),
                        $self->get_star(),
                        $section,
                        $self->get_pagenum(),
                        $self->get_adibreakout(),
                        $self->get_absplit(),
                        $self->get_version(),
                        $destination);

                $pagename = $temp_name;

        } elsif ( $ptype eq "SUPER_EXTENDED_FAXCODE" ) {

                $pagename = $self->get_pagename();

        } elsif ( $ptype eq "EXTENDED_FAXCODE" ) {

                $pagename = sprintf ("%s%03d%s",
                                        $self->get_pagename(),
                                        $self->get_julpubdate(),
                                        $self->get_pubcode());

        } elsif ( $ptype eq "FAXCODE" ) {

                $pagename = sprintf ("%s%03d%s",
                                        $self->get_pagename(),
                                        $self->get_julpubdate(),
                                        $self->get_pubcode());

        } elsif ( $ptype eq "EXTENDED_ROUTECODE" ) {

                $pagename = $self->get_pagename();

        } elsif ( $ptype eq "CLASS_ROUTECODE" ) {

                my $tempname = $self->get_pagename();
                $tempname =~ /([A-Z]+\.[A-Z0-9]{2}\.\d[A-Z]\d{2}[0A-Z]\.[A-Z]\d)/;
                $pagename = sprintf ("%s.%03d%s",
                                        $1,
                                        $self->get_julpubdate(),
                                        $self->get_pubcode());

        } elsif ( $ptype eq "ROUTECODE" ) {

                $pagename = sprintf ("%s.%03d%s",
                                        $self->get_pagename(),
                                        $self->get_julpubdate(),
                                        $self->get_pubcode());

        } elsif ( $ptype eq "WSJE_PDF" ) {

                $pagename = $self->get_pagename();

        } elsif ( $ptype eq "UNKNOWN" ) {

                $pagename = $self->gen_supername_18();

        }

        return $pagename;


}

sub gen_intl_name {

        #-- args:
        #-- merge => /\w\w/
        #-- type => /\w/

        my $self = shift;
        my %args = @_;
        my $proof = $args{proof};
        my $pubcode = $self->get_pubcode();

        #-- determine parameters not supplied by any domestic pagename
        #-- specication
        if (!defined $args{merge}) {
                $args{merge} = 'XX';
        }
        $args{type} = $args{type} || 'X';

        #-- determine whether to use a groupcode or sitelist
        my $gc = $self->get_groupcode();
        my $len = length $gc;
        if ($len > 0) {
                my $tmp = "-----";
                $gc = substr($tmp, 0, 5 - $len) . $gc;
        } else {
                $gc = sprintf("%05s",$self->get_bitfield());
        }

        #-- change date format to intl spec.
        my $pubdate = $self->get_pubdate();
        my ($month, $day, $yr) = $pubdate =~ /(\d\d)\/(\d\d)\/\d\d(\d\d)/;

        #-- determine what to use for edition field.
        #-- 0-1 star:
        #--     Europe = CT for continental
        #--     Asia = RE for Regular
        #-- 2+ star:
        #--     Europe = LM for Late Markets
        #--     Asia = SP for Sponsored
        #--
        my $edition;
        if ($pubcode eq 'G') {
                $edition = $self->get_star() < 2 ? 'CT' : 'LM';
        } elsif ($pubcode eq 'H') {
                $edition = $self->get_star() < 2 ? 'RE' : 'LR';
        } else {
                $edition = "00";
        }

        #-- create the section with leading dashes
        if ($proof eq 1) {
                $self->set_section($self->cfg->{global}->{wsje_proof_sect});
        }
        my $section = "--";
        $len = length $self->get_section();
        $section = substr($section, 0, 2 - $len) . $self->get_section();

        my $pagename = sprintf("%02d%02d%02d-%s-%s-%03d%s-%02s-%02s-%s%d-%s",
                #-- Day
                $day,

                #-- Month
                $month,

                #-- Year (2 digits)
                $yr,

                #-- delimiter (-)
                #-- publication code
                $pubcode,

                #-- delimiter (-)
                #-- section (2 character)
                $section,

                #-- delimiter (-)
                #-- pagenumber (3 digits)
                $self->get_pagenum(),

                #-- adi breakout (0,A-Z)
                $self->get_adibreakout(),

                #-- delimiter (-)
                #-- edition (2 character)
                $edition,

                #-- delimiter (-)
                #-- color merge (FL, 5C, TB for Europe, BK, 4C, 5C, TB for Asia)
                $args{merge},

                #-- delimiter (-)
                #-- type (S,D,T,E) obtain from function argument
                $args{type},

                #-- version
                $self->get_version(),

                #-- delimiter (-)
                #-- sitelist (5 characters, groupcode or sitelist)
                $gc
        );

        return $pagename;

}

sub to_string {
        my $self = shift;
        my $out =  "";
        $out .= "\npagename : " . $self->get_pagename() if $self->get_pagename();
        $out .= "\npubname : " . $self->get_pubname() if $self->get_pubname();
        $out .= "\npubcode : " . $self->get_pubcode() if $self->get_pubcode();
        $out .= "\npubdate : " . $self->get_pubdate() if $self->get_pubdate();
        $out .= "\njulpubdate : " . $self->get_julpubdate() if $self->get_julpubdate();
        $out .= "\ndateindex : " . $self->get_dateindex() if $self->get_dateindex();
        $out .= "\nsection : " . $self->get_section() if $self->get_section();
        $out .= "\npagenum : " . $self->get_pagenum() if $self->get_pagenum();
        $out .= "\nstar : " . $self->get_star() if $self->get_star();
        $out .= "\nversion : " . $self->get_version() if $self->get_version();
        $out .= "\neditions : " . $self->get_editions() if $self->get_editions();
        $out .= "\nherm_edition : " . $self->get_herm_edition() if $self->get_herm_edition();
        $out .= "\nsites : " . $self->get_sites() if $self->get_sites();
        $out .= "\nbitfield : " . $self->get_bitfield() if $self->get_bitfield();
        $out .= "\ngroupcode : " . $self->get_groupcode() if $self->get_groupcode();
        $out .= "\nadibreakout : " . $self->get_adibreakout() if $self->get_adibreakout();
        $out .= "\nabsplit : " . $self->get_absplit() if $self->get_absplit();
        $out .= "\npagetype : " . $self->get_pagetype() if $self->get_pagetype();
        $out .= "\ncreator : " . $self->get_creator() if $self->get_creator();
        $out .= "\nuniqueseqno : " . $self->get_uniqueseqno() if $self->get_uniqueseqno();
        $out .= "\nformatnum : " . $self->get_formatnum() if $self->get_formatnum();
        $out .= "\npagenametype : " . $self->get_pagenametype() if $self->get_pagenametype();
        $out .= "\n";
        return $out;
}

#sub extract_qms_editions {
#        my $self = shift;
#        my $content = "";
#
#        my $qmshost = $self->cfg->{qms}->{host};
#        my $qmsport = $self->cfg->{qms}->{port};
#        my $svcpath = $self->cfg->{qms}->{svcpath};
#
#        my %params = ( pagename => $self->get_pagename() );
#        my $params = join "&", map { "$_=$params{$_}" } sort keys %params;
#
#        my $url = qq(http://${qmshost}:${qmsport}${svcpath}?${params});
#
#        my $ua = LWP::UserAgent->new();
#        $ua->timeout(10);
#        my $response = $ua->get( $url );
#        if ($response->is_success()) {
#           $content = $response->decoded_content();
#        } else {
#           $self->{LAST_ERROR} = $response->status_line() . "; see \$DJ::Pagename->{QMS_RESPONSE} for more info.";
#           $self->{QMS_RESPONSE} = $response->decoded_content();
#           return 0;
#        }
#
#        if($content =~ /<editions>/) {
#           my @editions = $content =~ /<edition>\s*(.+?)\s*<\/edition>/sg;
#           $self->set_editions( uc(join(" ", sort @editions)) );
#        } elsif($content =~ /<error>(.+?)<\/error>/) {
#           $self->{LAST_ERROR} = $1;
#           return 0;
#        } else {
#           $self->{LAST_ERROR} = "Unknown response from service: $content\n";
#           return 0;
#        }
#        return 1;
#}

sub extract_pageid_editions {
        my $self = shift;
        my $pageid_type;
        my $return = 1;
        my $type = $self->get_pagenametype();

        #-- this is a really horrible hack, but that is how the
        #-- Sunday Journal is being processed through the existing
        #-- infrastructure, so here goes...
        #-- Sunday Journal pages will typically be printed from Hermes queues
        #-- with a routecode transmission name. But the group code
        #-- will not be a true groupcode, it will be the editioncode
        #-- for the specific partner newspaper as defined in AIMS
        if ( $self->get_pubcode() eq 'Z' ) {  #-- SUNJ
                $self->set_editions( $self->get_groupcode() );
                return $return;
        #-- Don't use the groupcode as the edition on intl pages composed domestically.
        #-- Only use the groupcode on intl pages coomposed overseas.
        #-- ASWJ_PDF and WSJE_PDF pagenametypes are used to convert intl pagenames
        #-- to domestic names for ETS (on pages composed overseas) so this is a good indicator
        #-- to go by when determining the above.
        } elsif ( $self->get_pubcode() eq 'G' && $type =~ /PDF/ ) {  #-- WSJE
                $self->set_editions( $self->get_groupcode() );
                return $return;
        } elsif ( $self->get_pubcode() eq 'H' && $type =~ /PDF/ ) {  #-- AWSJ
                $self->set_editions( $self->get_groupcode() );
                return $return;
        } elsif ( $self->get_pubcode() eq 'M' ) {  #-- SMARTMONEY
                # PageID doesn't handle SmartMoney
                $self->set_editions( "" );
                return $return;
        }

        my $pname = $self->get_pagename();
        if ($type =~ /ROUTE/) {
                $pageid_type = "route";
                # Strip off the julian date
                if ($type eq "EXTENDED_ROUTECODE") {
                        $pname = substr ($pname, 0, length ($pname) - 5);
                }
        } elsif ($type =~ /FAX/) {
                $pageid_type = "fax";
                # Strip off the julian date
                if ($type eq "SUPER_EXTENDED_FAXCODE") {
                        $pname = substr ($pname, 0, length ($pname) - 4);
                }
        } else {
                $pageid_type = "pds";
        }
        #-- added 01/03/2006 - Frank Sconzo
        #-- WSJ and BARRON'S now have separate PageID middle tiers.
        my @lookups = ();
        if($self->get_pubname() =~ /BARRONS/i) {
                push @lookups, "barrons_pageid", "pageid", "oldpageid";
        } else {
                push @lookups, "pageid", "oldpageid";
        }

        my ($count, $editions) = $self->get_pid_editions (
                \@lookups,
                #$self->cfg->{$lookup}->{host},
                #$self->cfg->{$lookup}->{port},
                $self->get_pubname(),
                $self->get_pubdate(),
                $self->get_star(),
                #$self->cfg->{$lookup}->{user},
                #$self->cfg->{$lookup}->{pass},
                $pname,
                $pageid_type,
                );

        if ($count > 0) {
                my $edition_list = "";
                foreach my $ed (@$editions) {
                        if (length $edition_list > 1) {
                                $edition_list .= " ".$ed;
                        } else {
                                $edition_list = $ed;
                        }
                }
                $self->set_editions($edition_list);
        } elsif ($count < 0 ) {
                $self->{LAST_ERROR} = $editions;
                $return = 0;    #-- indicate error occurred
        }

        return $return;
}

sub get_pid_editions {

        use IO::Socket;

        my      (
                $self,
                $lookups,
                #$pid_host,
                #$pid_port,
                $pub,
                $pubdate,
                $star,
                #$user,
                #$pass,
                $pagename,
                $pagename_type,
                ) = @_;

        my $connected = 0;
        my $user = "";
        my $pass = "";
        my $lookup = "";
        my $socket = undef;

        #-- for each potential connection lookup specified, attempt to connect.
        my $p = Net::Ping->new("tcp",1);
        foreach $lookup ( @{$lookups} ) {

                my $port = $self->cfg->{$lookup}->{port};
                my $host = $self->cfg->{$lookup}->{host};
                $p->{port_num} = $port;
                if($p->ping($host, 1)) {

                        $socket = IO::Socket::INET->new(
                                PeerAddr => $self->cfg->{$lookup}->{host},
                                PeerPort => $self->cfg->{$lookup}->{port},
                                Proto => "tcp",
                                Type => SOCK_STREAM,
                                Timeout => 1);

                        if($socket) {
                                $connected = 1;
                                $user = $self->cfg->{$lookup}->{user};
                                $pass = $self->cfg->{$lookup}->{pass};
                                last;
                        }
                } else {
                        $self->{WARNINGS} .= "Net::Ping failed to ${host}:${port}\n";
                }

        }

        unless($connected) {
                my $msg = join " ", map { $self->cfg->{$_}->{host} . ":" . $self->cfg->{$_}->{port} } @{$lookups};
                return (-1, "Could not open socket connection to PageID. Attempted with host list: ($msg).");
        }

        my $session = "create session:$pub:$pubdate:$star:$user:$pass:ANYTHING:CK:N\n";

        print $socket $session;

        # throw away first two lines returned from pid
        my $waste = <$socket>;
        if ($waste !~ /^ok/) {
                #-- error occurred connecting
                print $socket "quit\n";
                close($socket);
                return (-1,"Error occurred connecting: [$waste]");
        }
        $waste = <$socket>;     #-- ignore >> character

        my @editions = ();
        my $request = "get page editions:$pagename_type:$pagename:$star\n";

        print $socket $request;

        my $now = time;
        my $later;
        my $all_collected = 0;
        my $num_collected = 0;
        while (! $all_collected) {
                my $line = <$socket>;
                $later = time;
                if ($line =~ ">>") {
                        $all_collected = 1;
                } elsif (! ($line =~ "ok")) {
                        $num_collected ++;
                        # remove windows' newline characters
                        $line =~ s/\r\n//;
                        push @editions, $line;
                } elsif ($later - $now > 60) {
                        #-- if pid hangs, give it up to 60
                        #-- seconds to respond.
                        print $socket "quit\n";
                        close($socket);
                        return (-1,"Error occurred reading data from pageid. Aborting.");
                }
        }

        print $socket "quit\n";
        close($socket);

        return ($num_collected, \@editions);
}

sub get_supername_from_routecode {

        use IO::Socket;

        my      (
                $self,
                $pid_host,
                $pid_port,
                $pub,
                $pubdate,
                $star,
                $user,
                $pass,
                $pagename,
                $debug,
                ) = @_;

        my $socket = IO::Socket::INET->new(
                        PeerAddr => $pid_host,
                        PeerPort => $pid_port,
                        Proto => "tcp",
                        Type => SOCK_STREAM)
                or return (-1, "Could not open socket connection to PageID");

        my $session = "create session:$pub:$pubdate:$star:$user:$pass:ANYTHING:CK:N\n";

        print $socket $session;

        # throw away first two lines returned from pid
        my $waste = <$socket>;
        if ($waste !~ /^ok/) {
                #-- error occurred connecting
                print $socket "quit\n";
                close($socket);
                return (-1,"Error occurred connecting: [$waste]");
        }
        $waste = <$socket>;     #-- ignore >> character

        my @pages = ();
        my $supername;
        #my $request = "get page editions:$pagename_type:$pagename:$star\n";
        my $request = "get pages\n";

        print $socket $request;

        my $now = time;
        my $later;
        my $all_collected = 0;
        my $num_collected = 0;
        while (! $all_collected) {
                my $line = <$socket>;
                $later = time;
                if ($line =~ ">>") {
                        $all_collected = 1;
                } elsif (! ($line =~ "ok")) {
                        $num_collected ++;
                        # remove windows' newline characters
                        $line =~ s/\r\n//;
                        push @pages, $line;
                } elsif ($later - $now > 60) {
                        #-- if pid hangs, give it up to 60
                        #-- seconds to respond.
                        print $socket "quit\n";
                        close($socket);
                        return (-1,"Error occurred reading data from pageid. Aborting.");
                }
        }

        print $socket "quit\n";
        close($socket);

        # unisys;C5;MNYINV-4712045;N;EE,MW,SW; ;1;0;1;P1JW300026-0-C00500-1---EC;EPM.EC.1C050.A1;1C050ECA1 -- id:4216916;BG,BM
        # 0      1  2              3 4        5 6 7 8 9                          10              11                      12
        my $page = $pagename;

        #-- 1) Pageid names each route code starting with EPM instead of DIST or MART or CORP, etc.
        #-- 2) Also, classified pages may have higher version numbers than PageID knows about, so wildcard the version number.
        #-- 3) Don't match on groupcode since different groupcodes may be used by pageid and classified.
        #--    we'll do this by replacing the group code with the any character operator (.)
        #--    Instead compare the site codes derived from each route code.
        #-- TODO: Consider how to handle page names from classified like DIST.MW.1W11G.A1-SH
        #-- Use underscores to temporarily represent characters that should be matched with a wildcard
        $page =~ s/^\w\w\w\w{0,1}\.\S\S(\.\S\S\S\S\S\.\S)\d/EPM\.__${1}_/;

        #-- prepare the pagename as a valid regexp value (by escaping periods and dashes)
        $page =~ s/\./\\\./g;
        $page =~ s/\-/\\\-/g;

        #-- replace the underscores with the wildcard operator (.)
        $page =~ s/_/\./g;
        #$page =~ s/^EPM\\\.\w\w/EPM\\\.\.\./;

        my $p2 = new DJ::Pagename( pagename => $pagename );
        my $sites = $p2->get_sites();

        if($debug == 1) {
                open(DEBUG, ">>pid_pagelist.log");
        }

        my @potential_matches = ();
        my $found = 0;
        $supername = "UNMAPPED";
        foreach my $line ( @pages ) {
                if($debug == 1) {
                        print DEBUG "$line\n";
                }
                my @fields = split /;/,$line;
                if($fields[10] =~ /${page}/) {
                        #-- We have a match
                        #-- Check the cities match, but first make sure the city list from pageid contains something
                        if($fields[5] =~ /\S/) {
                                if($sites eq $fields[5]) {
                                        $supername = $fields[9];
                                        $found = 1;
                                } else {
                                        push @potential_matches, "$fields[9] ($fields[5])";
                                        #print STDERR "======> Site list did not match between pid [$fields[9]] and classified [$sites]\n";
                                }
                        } else {
                                #-- get a list of sites by extracting them from the pageid supername
                                my $p3 = new DJ::Pagename( pagename => $fields[9] );
                                my $pid_sites = $p3->get_sites();
                                if($pid_sites eq $sites) {
                                        $supername = $fields[9];
                                        $found = 1;
                                } else {
                                        push @potential_matches, "$fields[9] ($pid_sites)";
                                        #print STDERR "======> Site list did not match between pid [$pid_sites] and classified [$sites]\n";
                                }
                        }
                }
        }

        if(!$found) {
                print STDERR "UNMAPPED: $pagename [$sites]\n";
                if($#potential_matches >= 0) {
                        print STDERR "Potential Matches:\n ", join ("\n ", @potential_matches), "\ntelnet $pid_host $pid_port\n$session$request\n";;
                } elsif($#pages >= 0) {
                        print STDERR "No potential matches\ntelnet $pid_host $pid_port\n$session$request\n";
                } else {
                        print STDERR "No match found - no pages in pid for date specified.\ntelnet $pid_host $pid_port\n$session$request\n";
                }
        }
        if($debug == 1) {
                close(DEBUG);
        }
        return $supername;
}


#### determine if year is a leap year
sub isleap {

        my($self, $year) = @_;
        my $ret_val;
        if ($year < 1900) {
                $year += 1900;
        }
        if ($year % 400 eq 0) {
                $ret_val = 1;
        } else {
                if ($year % 100 eq 0) {
                        $ret_val = 0;
                } else {
                        if ($year % 4 eq 0) {
                                $ret_val = 1;
                        } else {
                                $ret_val = 0;
                        }
                }
        }
        return $ret_val;

}


sub get_next_pub_date_j {

        #-- this function works two ways:
        #-- 1) If no parameters are passed, it calculates the next pub date
        #--    after the current day.
        #-- 2) If a date is passed (month, date, year) then this function will
        #--    use that date as the starting point and determine the next publishing
        #--    date after that date.
        my $self = shift;
        my ($sec,$min,$hr,$mday,$mon,$year,$wday,$currjulday,$isdst) = localtime(time);
        my $skip_time_check = 0;
        if($#_ >= 2) { #-- three arguments
                #-- a date was passed, use it instead of today
                my ($m, $d, $y, $_skip_time_check) = @_;
                $m -= 1;
                $y -= 1900;
                #-- don't adjust the seconds, minutes or hour since we need to see if the time is before 5am
                ($mday,$mon,$year,$wday,$currjulday,$isdst) = (localtime(timelocal(0,0,1,$d,$m,$y)))[3..8];
                if(defined $_skip_time_check && $_skip_time_check =~ /^(1|0)$/) {
                        $skip_time_check = $_skip_time_check;
                }
        }
        my $jul_pubdate;
        $year += 1900;          #-- range is an offset from 1900
        $mon += 1;              #-- range from localtime is 0..11
        $currjulday += 1;       #-- range from localtime is 0..36[56]
        my $last_day_in_year;

        if ($self->isleap($year)) {
                $last_day_in_year = 366;
        } else {
                $last_day_in_year = 365;
        }

        #-- if the time is before 5am, assume we are in the previous day
        my $decremented;
        if (!$skip_time_check && $hr < 5) {
                $decremented = 1;
                if ($currjulday eq 1) {
                        if ($self->isleap($year - 1)) {
                                $last_day_in_year = 366;
                        } else {
                                $last_day_in_year = 365;
                        }
                        $currjulday = $last_day_in_year;
                        $year -= 1;
                } else {
                        $currjulday --;
                }
                $wday--;
                if($wday < 0) {
                        $wday = 6;
                }
        }

        # if base date = Saturday, pub date should be set to Monday
        # else pub date = tomorrow
        if ($wday eq 6) {
                # today is Saturday.
                #-- however, we may have made the base day equal to yesterday if the time is
                #-- earlier than 5am, so if the base date was Saturday, it may really be Friday
                #-- We do this for WSJ pages printed slightly after midnight, or even a few hours
                #-- printed after midnight (like during election nights)
                #if ($decremented ne 1) {
                #-- base date is still Sat
                $jul_pubdate = ($currjulday + 2);
                #} else {
                #       #-- base date is no longer Sat (it's really Friday), so we just increment by one
                #        $jul_pubdate = ($currjulday + 1) % $last_day_in_year;
                #}
        } else   {
                $jul_pubdate = ($currjulday + 1);
        }

        if($jul_pubdate > $last_day_in_year) {
                # pub date was incremented into next year
                $year++;
                $jul_pubdate -= $last_day_in_year;
        }

        #-- added December 2003
        #-- If the calculated pubdate is a holiday, then advance it to the next publishing day
        #-- convert the julian pubdate to m - d - y
        my ($fromj_datestr, $fromj_mos, $fromj_day, $fromj_year) = $self->jul_to_mmddyyyy( $jul_pubdate, $year );
        if($self->is_publishing_holiday($fromj_mos, $fromj_day, $year)) {
                #-- use recursion to get the next publishing day after the holiday
                #-- but skip the time check (before 5am) since we already did that once.
                ($jul_pubdate, $year) = $self->get_next_pub_date_j( $fromj_mos, $fromj_day, $year, 1 );
        }

        return ($jul_pubdate, $year);

}

sub is_publishing_holiday {
        #-- Assumtions: the pubcode/pubkey is already set.
        #-- Arguments: 3
        #--     1) month (1-12)
        #--     2) day (1-31)
        #--     3) year (4 digit)

        my $self = shift;
        my $pubkey = $self->pubkey();
        my($mon, $day, $year) = @_;

        #-- convert the date to MM/DD/YYYY format so it will match the
        #-- holiday dates listed in the Pagename.conf file
        my $datestr = sprintf("%02d/%02d/%04d", $mon, $day, $year);

        if(defined($self->cfg->{"${pubkey}_holidays"}{$datestr})) {
                return 1;
        } else {
                return 0;
        }
}


#### convert julian date to form MMDDYYYY
#### (use year if passed)
#### Take into account the following rule:
#### IF the pubdate is less than the current date,
#### it probably means it occurs in the next calendar
#### year, since julian dates roll back to 1 on Jan 1.
#### However, if the juldate is within the last 60 days,
#### we'll assume the page is for the current year.
#### Of course, if the pubdate is greater than the
#### current date, then we use the current year.
sub jul_to_mmddyyyy {

        my $self = shift;
        my ($juldate, $year) = @_;
        if (!defined($year)) {
                #-- default of 60 day window into the past
                my $pubdatewindow = $self->cfg->{global}->{pubdatewindow} || 60;
                my $julcurrday = (localtime())[7];

                if ( $julcurrday - $pubdatewindow < 0 ) {
                        # today is near the start of the year
                        my $oldestDate = 365 + ($julcurrday - $pubdatewindow);
                        if( $juldate > $oldestDate ) {
                                # USE LAST YEAR
                                $year = (localtime())[5] + 1899;
                        } else {
                                # USE CURR YEAR
                                $year = (localtime())[5] + 1900;
                        }
                } elsif( $julcurrday + $pubdatewindow > 365 ) {
                        # today is near the end of the year
                        my $maxDate = ($julcurrday - $pubdatewindow);
                        if($juldate < $maxDate) {
                                # USE NEXT YEAR
                                $year = (localtime())[5] + 1901;
                        } else {
                                # USE CURR YEAR
                                $year = (localtime())[5] + 1900;
                        }

                } else {
                        # use current year
                        $year = (localtime())[5] + 1900;
                }
        ###########################################################
        }


        #conv to integer
        $juldate = 0 + $juldate;

        my @month_days = qw(31 28 31 30 31 30 31 31 30 31 30 31);
        if ($self->isleap($year)) {
                #-- Feb should be 29, not 28 days
                $month_days[1] = 29;
        }

        my $mos = 0;
        while ($juldate > $month_days[$mos]) {
                $juldate -= $month_days[$mos];
                $mos ++;
                #-- check for invalid dates and roll them around
                #-- by resetting $mos
                if ($mos eq 12) {
                        print STDERR "DEBUGGING: Rolled around???\n";
                        $mos = 0;
                }
        }
        #-- the remainder in juldate will be the #days into the month

        if ($juldate eq 0) {
                $juldate = "1" ;
        }

        my $date = sprintf("%02d/%02d/%04d", ++$mos, $juldate, $year);

        #-- juldate here is actually mdays
        return ($date, $mos, $juldate, $year);
}


sub mmddyy_to_jul {

        my $self = shift;
        my $date = shift;
        my $juldate = 0;

        if ($date =~ /(\d\d)(\d\d)(\d\d)/) {

                my $mos = $1;
                my $day = $2;
                my $yr = $3;

                #-- assume current century
                my $cur_yr = (localtime())[5] + 1900;
                $cur_yr =~ s/(\d\d)\d\d/${1}00/;
                $cur_yr += $yr;

                my $pubdate = timelocal(0,0,0,$day,$mos - 1,$cur_yr - 1900);
                $juldate = (localtime($pubdate))[7] + 1;

        }

        return $juldate;

}

sub ddmmyy_to_jul {

        my $self = shift;
        my $date = shift;
        my $juldate = 0;

        if ($date =~ /(\d\d)(\d\d)(\d\d)/) {

                my $mos = $2;
                my $day = $1;
                my $yr = $3;

                $juldate = $self->mmddyy_to_jul("${mos}${day}${yr}");

        } else {

                $juldate = 0;

        }

        return $juldate;

}




#------------------------------------
#-- Public set methods
#------------------------------------
sub set_pagename {
        $_[0]->{_pagename} = $_[1];
}
sub set_pubname {
        $_[0]->{_pubname} = $_[1];
        my $key = $_[0]->cfg->{code_lookup}->{$_[1]};
        $_[0]->pubkey($key);
}
sub set_pubcode {
        $_[0]->set_pubname($_[0]->cfg->{aims_to_pub}->{$_[1]});
        $_[0]->{_pubcode} = $_[1];
}
sub guess_pubcode {

        #-- 10/24/2005 - as of now, only WSJ Classified pages should be named
        #-- without a pubdate or pubcode in the name. And since WSJ is now printed
        #-- on Friday afternoons for the Weekend Edition, the algorithm should
        #-- return J (WSJ) on Fridays.
        return "J";

        #my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
        #my $code;
        #if (($wday eq 5 && $hour > 14) ||
        #    ($wday eq 6 && $hour < 2)) {
        #
                #-- assume Barron's if it is Friday after 2pm or Saturday before 2am
        #       $code = 'B';
        #
        #} else {
        #
                #-- assume WSJ
        #       $code = 'J';
        #
        #}
        #
        #       return $code;

}
sub pubkey {
        if ($_[1]) {
                $_[0]->{_pubkey} = $_[1];
        } else {
                $_[0]->{_pubkey};
        }
}
sub set_pubdate {
        $_[0]->{_pubdate} = $_[1];
}
sub set_julpubdate {
        $_[0]->{_julpubdate} = $_[1];
        $_[0]->set_pubdate($_[0]->jul_to_mmddyyyy($_[1]));
}
sub set_dateindex {
        $_[0]->{_dateindex} = $_[1];
}
sub set_section {
        my $section = $_[1];
        $section =~ s/^-*//;
        $_[0]->{_section} = $section;
}
sub set_pagenum {
        #-- store page numbers without
        #-- leading zeros.
        my $pagenum = $_[1];
        $pagenum =~ s/^0+//;
        #dbglog($ds,"Setting pagenum: $pagenum");
        $_[0]->{_pagenum} = $pagenum;
}
sub set_star {
        $_[0]->{_star} = $_[1];
}
sub set_version {
        $_[0]->{_version} = $_[1];
}
sub set_editions {
        $_[0]->{_editions} = $_[1];
}
sub set_herm_edition {
        $_[0]->{_herm_edition} = $_[1];
}
sub set_sites {
        #-- put them into alphabetical order
        my @sites = sort split /\s+/,$_[1];
        $_[0]->{_sites} = join " ",@sites;
        $_[0]->{_sites} = " ", if length $_[0]->{_sites} < 1;
}
#-- set the site list and use it to determine either the groupcode
#-- or the bit string
sub set_distribution {
        my $self = shift;
        my $sites = shift;
        my $key = $self->pubkey();
        my $code = undef;
        my @sites = sort split /\s+/,$sites;

        #-- look for a groupcode lookup
        foreach my $groupcode ( keys %{$self->cfg->{"${key}_code"}} ) {
                my @list = sort split /\s+/,$self->cfg->{"${key}_code"}{$groupcode};
                my $list1 = "@list";
                my $list2 = "@sites";
                if ($list1 eq $list2) {
                        $code = $groupcode;
                        last;
                }
        }

        if (defined $code) {
                $self->set_groupcode($code);
        } else {
                #-- if there is no groupcode lookup, then use a bitstring...
                my $decsum;
                foreach my $site ( @sites ) {
                        #-- get the decimal equivalent for the site
                        $decsum += $self->cfg->{"${key}_site_to_dec"}->{$site};
                }
                #-- groupcode was probably already set, so let's unset it
                $self->set_groupcode("");

                #-- and now we'll set the hexfield
                my $formatspecifier = "%05s";
                if(defined $self->{_pagenameversion} && $self->{_pagenameversion} == 2) {
                        $formatspecifier = "%010s";
                }
                my $hex = sprintf($formatspecifier,dec2hex($decsum));
                $self->set_bitfield($hex);
        }

}
sub set_bitfield {
        my $bitfield = $_[1];
        if ($_[1] =~ /^-/ && length($_[1])) {
                $bitfield =~ s/^-*//;
                $_[0]->set_groupcode($bitfield);
        } else {
                $_[0]->{ _bitfield } = $bitfield;
                $_[0]->set_sites($_[0]->extr_list_from_hex($bitfield));
        }
}
sub set_groupcode {
        my $pub = $_[0]->get_pubcode();
        if ( $pub eq 'Z' ) {  #-- SUNJ
                $_[0]->set_sites( " " );
        } else {
                my $key = $_[0]->pubkey();
                $_[0]->set_sites($_[0]->cfg->{"${key}_code"}->{$_[1]});
        }
        $_[0]->{_groupcode} = $_[1];
}
sub set_adibreakout {
        $_[0]->{_adibreakout} = $_[1];
}
sub set_absplit {
        $_[0]->{_absplit} = $_[1];
}
sub set_pagetype {
        $_[0]->{_pagetype} = $_[1];
}
sub set_creator {
        $_[0]->{_creator} = $_[1];
}
sub set_uniqueseqno {
        $_[0]->{_uniqueseqno} = $_[1];
}
sub set_formatnum {
        $_[0]->{_formatnum} = $_[1];
}
sub set_pagenametype {
        $_[0]->{_pagenametype} = $_[1];
}
sub set_source_site_code {
        #-- We use 'C' to represent sites that
        #-- print WSJ classified pages.
        #-- We use 'E' to designate a source for
        #-- WSJ Europe pages.
        $_[0]->{_source_site_code} = $_[1];
}


#------------------------------------
#-- Private set methods
#------------------------------------

#-- Route code and fax code pagenames do not
#-- contain individual fields for ab split
#-- and adi indicator. This function attempts
#-- to determine the use of the overloaded
#-- field in those pagenames types.
sub set_overloaded_absplit {
        my $absplit = $_[1];
        if ($absplit eq "0") {
                $_[0]->set_absplit("0");
                $_[0]->set_adibreakout("0");
        } elsif ($absplit eq "Y") {
                $_[0]->set_absplit("A");
                $_[0]->set_adibreakout("0");
        } elsif ($absplit eq "Z") {
                $_[0]->set_absplit("B");
                $_[0]->set_adibreakout("0");
        } else {
                $_[0]->set_adibreakout($absplit);
                $_[0]->set_absplit("0");
        }
}

#-- Route and fax codes designate the star in a
#-- peculiar way.
#-- If the star field is less than three, then it
#-- is actually one less, otherwise it is
#-- exactly what is defined in the field except
#-- zero star is zero star.
#-- eg: 1=0, 2=1, 3=3, 4=4...
sub fix_star {
        my($self,$star) = @_;
        if ($star< 3 and $star> 0) {
                $star-= 1;
        }
        return $star;
}

#-- Return the handle to the config file object.
sub cfg {
        if ($_[1]) { $_[0]->{_cfg} = $_[1] };
        $_[0]->{_cfg};
}

#-- Convert a 5 digit hexadecimal number into a list
#-- of printing sites.
# The loop will iterate while counter <= 10000000000000000000b (524288)
#-- Issue For HEX code sites after LD were not appearing.Dated:10/09/2008
# The loop will iterate successfully for 30 sites.
# When more sites are to be added,then there has to be more gap between each scan of the XML folder.
# # The loop will iterate for 40 sites (counter <= 10000000000000000000000000000000000000000b) (decimal 1099511627776)
sub extr_list_from_hex {
        my $fortySites = 1099511627776;
        my $key = $_[0]->pubkey();
        my %sites = %{$_[0]->cfg->{"${key}_dec_to_site"}};
        my $self = $_[0];
        my $decbitstr = hex2dec($_[1]);
        my @binOfdecbitstr = dec2bin1($decbitstr);
        my $counter = 1;
        my $list = "";
        while($counter <= $fortySites) {
                my @binOfCounter = dec2bin1($counter);
                my $count = scalar @binOfCounter;
                my $cnt=0;
                while($cnt <= $count){
                        if (($binOfdecbitstr[$cnt] == 1) && ($binOfCounter[$cnt] == 1)){
                                if (length($list) > 1) {
                                $list .= " ".$sites{$counter};
                                } else {
                                $list = $sites{$counter};
                                }
                        }
                        $cnt = $cnt + 1;
                }
                # Shift the counter by an order of 2
                $counter = $counter * 2;
        }
        return $list;
}

sub dec2bin1 {
        my $str = shift;
        my $i=0;
        my @arr=();
        while ($str > 0){
                $arr[$i] = $str % 2;
                $str = int ($str / 2);
                $i = $i + 1;
        }
        return @arr;
}

sub extr_list_from_groupcode {
        my ($self,$groupcode) = @_;
        my $key = $_[0]->pubkey();
        my %gcodes = %{$_[0]->cfg->{"${key}_code"}};
        my $list        = $gcodes{$groupcode};
        return $list;
}


sub dec2bin {
        my $str = unpack("B32", pack("N", shift));
        $str =~ s/^0+(?=\d)//; # eliminate leading zeros
        return $str;
}

sub bin2dec {
        return unpack("N", pack("B32", substr("0" x 32 . shift, -32)));
}

sub dec2hex {
        my $hex = sprintf("%lx", shift);
}

sub hex2dec {
#       my $dec = hex shift;
my $str = shift;
        $str =~ s/^0+//;
        if($str eq "") {
                $str = 0;
        }
        my $val = 0;
        my $len = length($str) - 1;
        for(my $i = $len; $i >= 0; $i--) {
                my $char = substr($str,$len - ($i), 1);
                my $hex = hex($char);
                my $dec = $hex * 16 ** $i;
                $val += $dec;
        }
        return $val;

}


1;
#-- POD Documentation #--
__END__

=head1 NAME

DJ::Pagename - Perl module for parsing page transmissions names

=head1 VERSION

 $Revision: 1.24 $

=head1 HISTORY

 $Id: Pagename.pm,v 1.24 2004/11/05 19:35:04 root Exp root $
 $Author: root $
 $Date: 2004/11/05 19:35:04 $
 $Log: Pagename.pm,v $
 Revision 1.24  2004/11/05 19:35:04  root
 *** empty log message ***

 Revision 1.23  2002/06/25 23:23:21  root
 Corrected gen_unique_name to properly handle ADI and A/B Split pages.

 Revision 1.22  2002/06/24 20:33:43  root
 Corrected problem with intl page names having day and month backwards.

 Revision 1.21  2002/06/21 16:44:12  root
 Added set_distribution and modified the gen_uniquename to regenerate the supername
 instead of just returning it.

 Revision 1.20  2002/01/29 19:35:16  root
 Fixed problem with gen_pagename_18 using multi-character source sites.
 Added gen_intl_name.
 Make slightly better guesses at pubcodes.

 Revision 1.19  2001/12/10 21:45:16  root
 More changes to parsing section.
 Removed reliance on AppConfig - added function to get config parameters.
 Modified to allow groupcodes and bitfields to be based upon publication.

 Revision 1.17  2001/10/05 21:14:01  root
 Fixed gen_pagename_18 so it uses the correct source site.

 Revision 1.16  2001/09/19 15:12:41  root
 Added code to support city editions for AWSJ and replates.

 Revision 1.15  2001/09/19 14:58:29  root
 Added hack to allow groupcode for AWSJ pages to be the edition code as well.

 Revision 1.14  2001/08/22 21:57:06  root
 Added code to handle naming conventions for AWSJ pages.

 Revision 1.13  2001/08/11 17:55:43  root
 Removed a STDERR debugging message.

 Revision 1.12  2001/08/11 17:53:45  root
 Support classified pages with names like MART.MW.1A010.A1-SH.cpsiflatbed2

 Revision 1.11  2001/07/31 23:27:14  root
 updated set_groupcode to handle Sunday Journal:
 set sites to a space since they are not printed to a site.
 added get_unique_name to convert route codes to ext. route codes
 and fax codes to super-extended faxcodes.

 Revision 1.10  2001/06/22 13:45:12  root
 Modified pattern match for Classified pages named with Route Codes.
 The original pattern was a bit restrictive and when different RIPs were used
 in Orlando, the match failed. Now, I allow any non-space characters to trail the route code; but first I
 check for an extended route code.

 Revision 1.9  2001/06/13 22:37:49  root
 Fixed parser for all pagenames to accept groupcodes containing numbers as well as letters.

 Revision 1.8  2001/06/01 18:52:30  root
 Changed get_paged_editions function to return embedded groupcode for SunJ pages.

 Revision 1.7  2001/05/28 13:25:34  root
 Added code to parse WSJE name.

 Revision 1.6  2001/04/09 17:11:49  root
 Changed path to configuration file from /usr/midsys/site/ to
 /usr/local/lib/perl5/site_perl/5.005/DJ

 Revision 1.5  2001/04/09 17:07:17  root
 Modified extract_pid_editions to strip off julian dates if the
 pagename type is extended routecode or super extended fax code.

 Revision 1.3  2000/10/04 12:52:58  root
 Added to_string method.

=head1 SYNOPSIS

$page = DJ::Pagename->new("P1JW36001D-0-A00100-11FFFF");
print $page->get_sites();

$page = DJ::Pagename->new();
$page->parse("EPM.XE.1A010.A1.360J");
print $page->get_pagenum();
print $page->gen_supername_18();

=head1 DESCRIPTION

This module will parse eight different variants of Dow Jones' page
transmission names.

 Designations            Examples
 Super Extended Faxcode: 1C090XEA1XE139J
 Extended Faxcode:       1C090XEA1XE
 Faxcode:                1C090XEA1
 Extended Routecode:     EPM.XA.1A010.A1.139J
 Routecode:              EPM.XA.1A010.A1
 PDF for WSJ Europe:     WSJE_051401_P13.pdf
 1.7 Specification:      P1JW13901C-0-A00100-1---XA
 1.8 Specification:      P1JW13901C-0-A00100-11FFFF
 2.0 Specification:      P2JW13901C-0-A00100-1038201020C
 2.0 Specification:      P2JW13901C-0-A00100-1--------XE

=head1 ENVIRONMENT

=head1 DIAGNOSTICS

=head1 BUGS

=head1 FILES

Pagename.conf

=head1 MISCELLANEOUS

To test gen_unique_name, run this perl code:

#!/usr/local/bin/perl

use DJ::Pagename;

@names = qw(
        EPM.XE.1A010.A1.cpisflatbed1
        EPM.XE.1A010.A1.cpisflatbed
        EPM.XE.1A010.A1
        EPM.XE.1A010.A1.orrip2fb
        P1JW195013-0-A00100-1---XE
        P1JW195013-0-A00100-11FFFF
        1C090XEA1XE139J
        1C090XEA1XE
        1C090XEA1
);


$p = new DJ::Pagename ( pagename => 'EPM.XE.1A010.A1.cpisflatbed1');


foreach $name ( @names ) {
        $p->parse($name);
        print $p->get_pagename(),"\n",$p->gen_unique_name(),"\n\n\n";
}

=head1 METHODS

=over 4

=item new( "P2JW001001-0-A00100-1--------XE" )

Constructor for the Pagename object. If a string is passed, it will attempt to parse the string as a pagename using the parse method.

=item parse( pagename => "P2JW001001-0-A00100-1--------XE" )

Parse the argument as a pagename, and set all internal attributes to reflect that name.

=item to_string()

After parsing a pagename with the constructor, or the set_pagename method, print a representation of the pagename.

=item get_pagename()

Return the pagename

=item get_pubname()

Return the name of the publication

=item get_pubcode()

Return the code for the publication

=item get_pubdate()

Return the Publication Date in format mm/dd/yyyy

=item get_julpubdate()

Return the publication date in julian format 

=item get_dateindex()

=item get_section()

Return the section letter of the page

=item get_pagenum()

Return the page number of the page

=item get_star()

Return the numeric star (zero-based)

=item get_version()

Return the page version number

=item get_editions()

Return the list of editions, after calling get_pid_editions

=item get_sites()

Return the list of sites based on the group code or hex field

=item get_site_names()

Return the list of site names (as an array) based on the group code or hex field

=item get_bitfield()

Return the bit field of the hex group distribution

=item get_groupcode()

Return the group code representing the list of sites the page is destined for

=item get_adibreakout()

Return the ADI (area of dominant influence) character (0, A-Z)

=item get_absplit()

Return the A/B split indicator (A or B)

=item get_pagetype()

Return the page type (eg: P for press ready)

=item get_creator()

Return the origin/creator code (typically W for WFC)

=item get_uniqueseqno()

Return the unique sequence numnber (three digit hex)

=item get_formatnum()

Return the format of the pagename used to describe this pagename

=item get_pagenametype()

Return a string representing how the pagename was parsed. 

=item get_source_site_code()

=item extract_qms_editions()

Connect to the QMS Page Naming service and use the "describe" method to determine the editions for this pagename.

=item extract_qms_editions()

Connect to the PageID socket interface and request the editions for this page.
*This method is deprecated in favor of extract_qms_editions.

=item get_pid_editions()

A wrapper function for extract_pageid_editions, which handles special publications such as Sunday Journal in special ways.
*This method is deprecated in favor of extract_qms_editions.

=item get_supername_from_routecode()

Convert an old-style pagename (routecode) to a new "Supername" version 2 page name.
eg: EPM.XE.1A010.A1 to P2JW001000-0-A00100-1--------XE

=item get_next_pub_date_j()

Determine the next publishing date, of not specified in the pagename, by using the configured publishing holidays in the config file.

=item set_pagename("P2JW179000-0-A00600-1--------XE")

Set the pagename and have it parsed.

=item set_pubname("WSJ")

Set the publication name, based on the configuration file Pagename.conf.

=item set_pubcode("J")

Set the publication code, based on the configuration file Pagename.conf.

=item set_pubdate("06/27/2014")

Set the publication date of the page, in mm/dd/yyyy format.

=item set_julpubdate(179)

Set the publication date of the page, in julian format.

=item set_dateindex(int)

Deprecated

=item set_section("A")

Set the section letter of the page.

=item set_pagenum(23)

Set the page number of the page.

=item set_star(0)

Set the star of the page. 0 indicates 2-star, 2 indicates 3-star, and 4 indicates 4-star.

=item set_version(1)

Set the version number of the page.

=item set_editions("EE CE MW WE")

Set the list of editions as a string.

=item set_herm_edition("")

Deprecated.

=item set_sites("CK SB")

Set the list of sites, but do not attempt to derive the group code from it.

=item set_distribution("CK SB")

Set the site list and use it with the config file to determine either the groupcode or the bit string.

=item set_bitfield("0EFFB7178F")

Set the hexadecimal list of sites, and use the config file to convert to a site list.

=item set_groupcode("XE")

Set the groupcode, and use the config file to set the list of sites.

=item set_adibreakout("D")

Set the Area of Dominant Influcence character to indicate the page "breakout" letter, or 0 for none.

=item set_absplit("B")

Set the indicator of whether this page will be an advertising A/B split, or 0 for none.

=item set_pagetype("P")

Set the page type. "P" means press-ready.

=item set_creator("W")

Set the originating site of the page (where it was transmitted from.) W stands for WFC.
This field is deprecated, and hard-coded to W.

=item set_uniqueseqno("01C")

Set the three-digit hexadecimal code representing the unique (within one day) number for this page.

=item set_formatnum(2);

Set the format number (specification) of the pagename.

=item set_pagenametype("")

A string representing how the pagename was parsed. (internal)


=head1 SEE ALSO

 DJ::Dates
 DJ::Log

=head1 AUTHOR

Frank J. Sconzo, frank.sconzo@dowjones.com

=head1 COPYRIGHT

Copyright (c) 2001, Dow Jones and Company. All Rights Reserved.

